# New Structure

- **Operation = Edges + Function**  
    _(atomic; not a container)_
    
- **Container = {Edges, Operations}**  
    _(structure only; no wiring)_
    
- **Node = Container ⊗ Network**  
    _(an instantiated Container; wires connect Edges)_

Container
├─ Edges (Flow)
├─ Operations
│        └─ Edges (Flow)
└─ (no wiring here)

Network (Instantiation of Container) → Node
└─ Wires connect Edges of that Container/Node

## Container
Holds:
- Edges
- Operations

## Operation
Holds:
- Edges
Has:
- Function

## Edge
Has:
- Flow Type

## Network
A Network is the instantiated form of a Container, turning it into a Node.

# Semantic Node
```button
name New Semantic Node
type note(Node ID/NODE-<% tp.date.now("YYYYMMDDHHmmss") %>) text
action ---
ID: NODE-<% tp.date.now("YYYYMMDDHHmmss") %>
CONT_ID: ""
Context: "Describe what this Node represents, do or mean."
---
# Node
Node is an instance of a Container.
Nodes exist in Workspaces and Projects.
templater true
```

# Container Template
```button
name New Container Template
type note(Structure/Container ID/CONT-<% tp.date.now("YYYYMMDDHHmmss") %>) text
action ---
ID: CONT-<% tp.date.now("YYYYMMDDHHmmss") %>
Context: "Describe what this Container represents, do or mean."
---
# Object
Container is an Object that can have Geometry, Material, Mass, Physical Properties or just be a conceptual boundary.

# Simplest representation
The simplest representation of a Container is a circle.

templater true
```

# Operation Template
```button
name New Operation Template
type note(Structure/Operation ID/OPER-<% tp.date.now("YYYYMMDDHHmmss") %>) text
action ---
ID: OPER-<% tp.date.now("YYYYMMDDHHmmss") %>
CONT_ID: ""
Context: "Describe what this Operation represents, do or mean."
---
# Operation
Operation can be anything from a Constant to another Container.

# Simplest representation
The simplest representation of an Operation is a circle, slightly larger than Edges.
It sits in the middle of a Container.
When more than one is created, the Operators space out around the center of the Container.

templater true
```

# Edges Template
```button
name New Edges Template
type note(Structure/Edges ID/EDGE-<% tp.date.now("YYYYMMDDHHmmss") %>) text
action ---
ID: EDGE-<% tp.date.now("YYYYMMDDHHmmss") %>
CONT_ID: ""
OPER_ID: ""
Label: "Give the new Edges a name"
Type: ""
---
# Edges
Edges are contact points. Screw holes, vias, function inputs and/or outputs.

# Simplest representation
The simplest representation of Edges are small circles on the edge of a Container and Operation.
When more than one is created, the Edges space out in equidistant angles.

templater true
```

# Network Template
```button
name New Network Template
type note(Structure/Network ID/NETW-<% tp.date.now("YYYYMMDDHHmmss") %>) text
action ---
ID: NETW-<% tp.date.now("YYYYMMDDHHmmss") %>
EDGE_ID: ""
Context: "Describe what this Network represents, do or mean."
---
# Network
Network can be anything from a straight line from Edge to Edge to complex routing on a PCB from Edges to Operations to Edges.

# Simplest representation
The simplest representation of a Network is a line from an Edge to an Edge.

templater true
```

# Flow Template
```button
name New Flow Template
type note(Structure/Flow ID/FLOW-<% tp.date.now("YYYYMMDDHHmmss") %>) text
action ---
ID: FLOW-<% tp.date.now("YYYYMMDDHHmmss") %>
EDGE_ID: ""
Context: "Describe what this Flow represents, do or mean."
---
# Flow
Flow can be anything from an Output, Input to High-Z or null.
templater true
```

# Instantiation Template
```button
name New Instantiation Template
type note(Instantiation ID/INST-<% tp.date.now("YYYYMMDDHHmmss") %>) text
action ---
ID: INST-<% tp.date.now("YYYYMMDDHHmmss") %>
NODE_ID: ""
CONT_ID: ""
Context: "Describe what this Instantiation represents, do or mean."
---
templater true
```

# Parsing Template
```button
name New Parsing Template
type note(Parsing ID/PARS-<% tp.date.now("YYYYMMDDHHmmss") %>) text
action ---
ID: PARS-<% tp.date.now("YYYYMMDDHHmmss") %>
Context: "Describe what this Parsing represents, do or mean."
---
templater true
```