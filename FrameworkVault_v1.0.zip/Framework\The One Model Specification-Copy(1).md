# 🟩 **The One Model Specification**

### _A Minimal Semantic–Computational Architecture_

### _by René Bjerg Madsen_

### _Draft — February 2026_

---

## **1. Core Principle (Mantra)**

> **Complexity is added only when the previous layer can’t express what you need.**

This principle governs every layer of the model.  
All structures, semantics, and compositions follow this rule.

---

## **2. The One Model**

The entire architecture is based on a **single recursive idea**:

### **A Node is anything with identity, interface, and behavior.

A Structure is anything that produces a Node.  
All Structures are made of Nodes.**

This creates a **fractal**, **self-similar**, infinitely extensible system.

---

## **3. Atomic Node Specification (The Minimal Unit)**

Atomic Nodes narrow all concepts to their simplest form.

Every Node contains:

- **id** — stable identity
- **input** — optional, because constants exist
- **output** — optional, surfaced through Structure
- **description** — semantic surface, keywords
- **Process** — internal value, function, mapping, or behavior

Nodes represent the smallest possible semantic or computational unit.

Atomic Nodes are **Simple, Modular, Reusable, Extensible, Scalable** —  
they _fulfill SMoRES by definition_.

---

## **4. Structural Layers (Semantic Structures)**

Semantic Structures extend Atomic Nodes.  
Each Structure Type exposes one dimension of composition.

There are four Structural Types:

---

### **4.1 Structure Type: Container (Scope / Namespace)**

**What belongs together.**

- Closed namespace
- Contains Nodes
- No Process
- No Flow
- No execution
- No relations implied
- Defines conceptual or representational grouping
- Acts like a filter: “only contained nodes are visible here”

A Container becomes a Node **only** when combined with the next structure types.

---

### **4.2 Structure Type: Network (Relations / Interface)**

**What relates to what.**

- Defines relationships between Nodes within a Container
- Surfaces Container-level input and output ports
- Assigns meaning to internal relationships
- Gives a Container its _interface_
- Does not define execution order
- Does not define behavior

A Network turns a Container into something that _can_ behave like a Node  
(by defining its input/output surface).

---

### **4.3 Structure Type: Flow (Execution Topology)**

**What output connects to what input.**

- Connects Node outputs to Node inputs
- Creates directed execution paths
- Defines computational behavior between Nodes
- Produces composite Process** from the interaction of Nodes
- Does not define when execution occurs

Flow is where _behavior emerges_ at a higher level.

---

### **4.4 Structure Type: Scheduling (Temporal Semantics)**

**When structures run.**

- Defines activation
- Defines sequencing
- Defines state transitions
- Defines timing
- Allows Flow structures to operate as:
    - State machines
    - Sequence machines
    - Triggered systems
    - Cycles
    - Orchestrated processes

Scheduling turns static Flow into dynamic runtime behavior.

---

## **5. The Fractal Rule (Recursion)**

### **Container + Network + Flow + Scheduling → Composite Node**

Once a Container has:

- A **Network-defined interface** (inputs/outputs)
- A **Flow-defined behavior** (composite Process)
- A **Scheduling-defined activation** (runtime semantics)

…it becomes a **higher-level Node** with:

```
id
input
output
description
Process (composite)
```

This Node can now be placed inside another Container.

Thus:

### **Node → Structure → Node → Structure → Node …**

The system is infinitely composable.

This is the One Model.

---

## **6. SMoRES Compliance**

The model satisfies SMoRES naturally:

- **Simple:** Every Node is minimal
- **Modular:** Nodes and Structures are encapsulated
- **Reusable:** Nodes and Structures are independent and composable
- **Extensible:** New Structure Types extend behavior without changing Nodes
- **Scalable:** Recursion enables infinite layering

The architecture uses the _least number of rules needed_ for expressive power.

---

## **7. Summary in One Sentence**

> **Atomic Nodes define the simplest form of meaning and behavior.  
> Semantic Structures describe how those Nodes combine, relate, flow, and run.  
> Together they form one recursive, fractal model that only adds complexity when needed.**

---

## **8. Current Version Status**

This specification represents the minimal form of the One Model, based on the discoveries made in early February 2026.

Future additions may include:

- Formal examples
- Diagram conventions
- Structure Templaters
- Node Templaters
- Canvas definitions
- Execution semantics

But the One Model itself is complete.