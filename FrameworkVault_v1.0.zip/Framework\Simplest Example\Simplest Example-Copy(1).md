A + B = C

## Container
- A
- B
- C
- +

## Edges
A: Integer
B: Integer
C: Integer

## Operation
- +

## Network
A - +
B - +
C - +

## Flow
A -> +
B -> +
+-> C