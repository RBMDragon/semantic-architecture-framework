_The universal ontology for Containers, Nodes, Edges, Operations, Networks, and Flows._

---

## 🧱 **1. Container**

**Ontological role:** Definition of form, structure, and local elements.  
**Semantic function:** _“What is this object?”_

**Properties**

- `ID`
- `Context`
- `Edges[]`
- `Operations[]`
- `Network[]`
- (optional) `Geometry`, `Material`, `Mass`, `Properties`

**Rules**

- A Container is a _definition_, not an instance.
- A Container may reference Edges, Operations, and Network.
- A Container must **not** reference Nodes or Flow.

---

## 🔌 **2. Edges**

**Ontological role:** Interface points.  
**Semantic function:** _“How can this object connect to others?”_

**Properties**

- `ID`
- `CONT_ID`
- `Label`
- `Type`

**Rules**

- Edges belong to a Container.
- Edges must **not** reference Network or Flow.

---

## ⚙️ **3. Operation**

**Ontological role:** Function or transformation.  
**Semantic function:** _“What can this object do?”_

**Properties**

- `ID`
- `CONT_ID`
- `Context`

**Rules**

- An Operation is a function.
- If an Operation has physical form → it _is_ a Container.
- Operations must **not** reference Nodes or Flow.

---

## 🕸️ **4. Network**

**Ontological role:** Relations and connections.  
**Semantic function:** _“How do things relate or link together?”_

**Properties**

- `ID`
- `CONT_ID`
- `EDGE_ID`
- `OPER_ID`
- `Context`

**Rules**

- Network binds Edges and Operations.
- Network may reference Container, Edges, and Operations.
- Network must **not** reference Flow directly.

---

## 💧 **5. Flow**

**Ontological role:** Behavior, state, movement.  
**Semantic function:** _“What happens in this network?”_

**Properties**

- `ID`
- `NETW_ID`
- `Context`

**Rules**

- Flow runs _on top of_ Network.
- Flow may only reference Network.
- Flow must **not** reference Container, Edges, or Operations.

---

## 🧩 **6. Node**

**Ontological role:** Instance of a Container.  
**Semantic function:** _“A concrete occurrence inside a Workspace or Project.”_

**Properties**

- `ID`
- `CONT_ID`
- `Workspace_ID`
- (optional) `Overrides`

**Rules**

- A Node is runtime.
- Nodes exist only in Workspaces and Projects.
- Nodes must not reference Libraries.

---

## 🗂️ **7. Workspace**

**Ontological role:** Semantic space.  
**Semantic function:** _“Where Nodes live and connect.”_

**Properties**

- `ID`
- `Nodes[]`
- `Networks[]`
- `Flows[]`

---

## 📚 **8. Library**

**Ontological role:** Definition storage.  
**Semantic function:** _“Where Containers live.”_

**Properties**

- `ID`
- `Containers[]`

---

## 🏗️ **9. Instantiation**

**Ontological role:** Creation action.  
**Semantic function:** _“Create a Node from a Container.”_

**Properties**

- `ID`
- `CONT_ID`
- `Workspace_ID`
- `Overrides`
- `Context`

**Rules**

- Instantiation creates a Node.
- Instantiation must not reference a Node beforehand.

---

# ⭐ **Why this works**

This specification gives you:

- a **clean ontology**
- a **stable dependency graph**
- a **universal semantic core**
- a **foundation for any domain**
- a **structure Obsidian can actually hold**

It’s the kind of thing that scales from tiny notes to full system models without breaking.

---