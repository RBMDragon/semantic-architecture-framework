Dette er faktisk den reneste måde at adskille dem på:

| Entity | Can know | Cannot know |
| Container | Edges, Operation, Network | Node, Flow |
| Edges | Container | Network, Flow
| Operation | Container | Node, Flow |
| Network | Container, Edges, Operation | Flow |
| Flow | Network | Container, Edges, Operation |

Denne tabel er _guld_.  
Den er domæne‑agnostisk.  
Den er fraktal.  
Den er stabil.